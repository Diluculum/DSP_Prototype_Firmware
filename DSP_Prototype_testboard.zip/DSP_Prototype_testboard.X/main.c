/* 
 * File:   main.c
 * Author: smcch
 *
 * Created on May 2, 2023, 3:54 PM
 */

#include "main.h"

void INIT(void){
    INIT_PIN();
}
/*
 * 
 */
void main(void) {
    INIT();
    while(true){
        RB4 = 0;
        __delay_ms(1000);
        RB4 = 1;
    }
}

void heartbeatTOGL(void){
    heart = ~heart;
}

/*
 * int main(int argc, char** argv)
 */