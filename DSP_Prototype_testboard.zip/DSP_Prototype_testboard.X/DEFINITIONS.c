#include "DEFINITIONS.h"

void INIT_PIN(void){
    TRISB = 0b00000110;
    TRISC = 0b00101100;
    TRISD = 0b00000010;
    
//    heart = 0;
}