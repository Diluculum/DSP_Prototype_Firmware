#ifndef MAIN_H
#define MAIN_H

// include files to use in main
#include <xc.h>
#include "configuration.h"
#include "DEFINITIONS.h"
#include <stdlib.h>
#include <stdbool.h>
#include <conio.h>

// method primatives
void INIT(void);
void heartbeatTOGL(void);

#endif


